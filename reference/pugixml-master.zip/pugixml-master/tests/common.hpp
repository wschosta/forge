#ifndef HEADER_TEST_COMMON_HPP
#define HEADER_TEST_COMMON_HPP

#include "test.hpp"

using namespace pugi;

#endif
